﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Quiz : MonoBehaviour
{
    public GameObject ui;
    public bool quizOpen;
    public Text slot1;
    public Text slot2;
    public Text slot3;
    public int i;
    public int j;
    public int k;
    public float num;

    public Button slot1Option1;
    public Button slot1Option2;
    public Button slot1Option3;

    public Button slot2Option1;
    public Button slot2Option2;
    public Button slot2Option3;

    public Button slot3Option1;
    public Button slot3Option2;
    public Button slot3Option3;

    public Text slot1Answer1;
    public Text slot1Answer2;
    public Text slot1Answer3;

    public Text slot2Answer1;
    public Text slot2Answer2;
    public Text slot2Answer3;

    public Text slot3Answer1;
    public Text slot3Answer2;
    public Text slot3Answer3;

    public GameObject question1;
    public GameObject question2;
    public GameObject question3;

    public GameObject result1Correct;
    public GameObject result1Wrong;
    public GameObject result2Wrong;
    public GameObject result2Correct;
    public GameObject result3Correct;
    public GameObject result3Wrong;


    public GameObject allQ1Answered;
    public GameObject allQ2Answered;
    public GameObject allQ3Answered;
    public GameObject shop;


    public string firstQ = "What is a pathogen?";
    public string answer1A = "A red blood cell";
    public string answer2A = "A germ";
    public string answer3A = "A white blood cell";

    public string secondQ = "Which of these organs is the largest?";
    public string answer1B = "Heart";
    public string answer2B = "Brain";
    public string answer3B = "Liver";

    public string thirdQ = "What is the purpose of the immune system?";
    public string answer1C = "To prevent disease and infection.";
    public string answer2C = "To digest food and drink";
    public string answer3C = "To move parts of the body";

    public string fourthQ = "What is the first line of defence against infection in humans?";
    public string answer1D = "The skin";
    public string answer2D = "The bloodstream";
    public string answer3D = "The brain";

    public string fifthQ = "How do vaccines aid the immune system";
    public string answer1E = "They give the body more fluids";
    public string answer2E = "They raise the body's temperature";
    public string answer3E = "They increase the body's defences against a specific virus";

    public string sixthQ = "In a healthy human adult, what percentage of the blood consists of white blood cells.";
    public string answer1F = "1%";
    public string answer2F = "5%";
    public string answer3F = "10%";

    public string seventhQ = "Which of these sources of infection require a host to survive? ";
    public string answer1G = "Fungi";
    public string answer2G = "Virus";
    public string answer3G = "Bacteria";

    public string eightQ = "Which of these is NOT a symtpom of infection?";
    public string answer1H = "Fever";
    public string answer2H = "Aches and pains";
    public string answer3H = "Scratches on the skin";

    public string ninthQ = "Which of thse options is a method of obtaining an infection";
    public string answer1I = "Eating undercooked meat";
    public string answer2I = "Drinking too much alcohol";
    public string answer3I = "Consuming too much sugar";

    public string tenthQ = "Which of these habits will lower the chance of getting an infection";
    public string answer1J = "Getting plenty of fresh air";
    public string answer2J = "Covering cuts or scrapes";
    public string answer3J = "Exercising daily";

    public string eleventhQ = "How does a white blood cell defend the body?";
    public string answer1K = "It identifies foreign objects and ingests them";
    public string answer2K = "It prevents infectious agents from entering the body";
    public string answer3K = "It creates a barrier to prevent infectious agents entering the bloodstream";

    public string twelthQ = "An immunoglobulin is more commonly known as...";
    public string answer1L = "A red blood cell";
    public string answer2L = "An antibody";
    public string answer3L = "A platelet";

    public string thirteenthQ = "How do antibodies know which cells are foreign to the body?";
    public string answer1M = "They have a drastic variation in colour";
    public string answer2M = "They differ greatly in size";
    public string answer3M = "The molecules on the surface are different to those on molecules found in the body";

    public string fourteenthQ = "Which of these actions is performed by the immune system upon detection of an infection?";
    public string answer1N = "Inflammation of the infected area";
    public string answer2N = "Reducing the red blood cell count in the infected area";
    public string answer3N = "Making the body sweat";

    public string fifteenthQ = "What is an antigen?";
    public string answer1O = "A substance that is capable of damaging an organ";
    public string answer2O = "A substance that is capable of damaging the immune system";
    public string answer3O = "A substance that is capable of stimulating a response from the immune system";





    public bool question1AAnswered = false;
    public bool question2AAnswered = false;
    public bool question3AAnswered = false;
    public bool question4AAnswered = false;
    public bool question5AAnswered = false;

    public bool question1BAnswered = false;
    public bool question2BAnswered = false;
    public bool question3BAnswered = false;
    public bool question4BAnswered = false;
    public bool question5BAnswered = false;

    public bool question1CAnswered = false;
    public bool question2CAnswered = false;
    public bool question3CAnswered = false;
    public bool question4CAnswered = false;
    public bool question5CAnswered = false;


    public void ToggleQuizMenu()
    {
        shop.SetActive(!shop.activeSelf);
        ui.SetActive(!ui.activeSelf);


        if (ui.activeSelf)
        {
            Time.timeScale = 0f;
        }
        else
        {
            Time.timeScale = 1f;
        }
        num = Random.Range(0f, 100f);

        if (num <= 20)
        {
            question1.SetActive(true);
            result1Correct.SetActive(false);
            result1Wrong.SetActive(false);

            question2.SetActive(true);
            result2Correct.SetActive(false);
            result2Wrong.SetActive(false);

            question3.SetActive(true);
            result3Correct.SetActive(false);
            result3Wrong.SetActive(false);

            LessThan20Questions();
            
        }

        if (num <= 40 && num > 20)
        {
            question1.SetActive(true);
            result1Correct.SetActive(false);
            result1Wrong.SetActive(false);

            question2.SetActive(true);
            result2Correct.SetActive(false);
            result2Wrong.SetActive(false);

            question3.SetActive(true);
            result3Correct.SetActive(false);
            result3Wrong.SetActive(false);

            Between20And40();
            
        }

            if (num <= 60 && num > 40)
            {
                question1.SetActive(true);
                result1Correct.SetActive(false);
                result1Wrong.SetActive(false);

                question2.SetActive(true);
                result2Correct.SetActive(false);
                result2Wrong.SetActive(false);

            question3.SetActive(true);
            result3Correct.SetActive(false);
            result3Wrong.SetActive(false);

            Between40and60();
            }

            if (num <= 80 && num > 60)
            {
                question1.SetActive(true);
                result1Correct.SetActive(false);
                result1Wrong.SetActive(false);

                question2.SetActive(true);
                result2Correct.SetActive(false);
                result2Wrong.SetActive(false);

            question3.SetActive(true);
            result3Correct.SetActive(false);
            result3Wrong.SetActive(false);

            Between60And80();
               
            }

            if (num > 80)
            {
                question1.SetActive(true);
                result1Correct.SetActive(false);
                result1Wrong.SetActive(false);

                question2.SetActive(true);
                result2Correct.SetActive(false);
                result2Wrong.SetActive(false);

            question3.SetActive(true);
            result3Correct.SetActive(false);
            result3Wrong.SetActive(false);

            Over80();
            }
            if (question1AAnswered && question2AAnswered && question3AAnswered && question4AAnswered && question5AAnswered)
            {
                allQ1Answered.SetActive(true);
                question1.SetActive(false);
            }

            if (question1BAnswered && question2BAnswered && question3BAnswered && question4BAnswered && question5BAnswered)
            {
                allQ2Answered.SetActive(true);
                question2.SetActive(false);
            }

            if (question1CAnswered && question2CAnswered && question3CAnswered && question4CAnswered && question5CAnswered)
        {
            allQ3Answered.SetActive(true);
            question3.SetActive(false);
        }

            
        
    }

        public void PressButton1A()
        {
            i = 1;
            CheckAnswer();
        }

        public void PressButton2A()
        {
            i = 2;
            CheckAnswer();
        }

        public void PressButton3A()
        {
            i = 3;
            CheckAnswer();
        }

        public void PressButton1B()
        {
            j = 1;
            CheckAnswer();
        }

        public void PressButton2B()
        {
            j = 2;
            CheckAnswer();
        }
        public void PressButton3B()
        {
            j = 3;
            CheckAnswer();
        }

        public void PressButton1C()
        {
            k = 1;
            CheckAnswer();
        }

        public void PressButton2C()
        {
            k = 2;
            CheckAnswer();
        }

        public void PressButton3C()
        {
            k = 3;
            CheckAnswer();
        }
        public void CheckAnswer()
        {
            if (slot1.text == firstQ)
            {

                if (i == 1)
                {
                    EasyWrongAnswer();
                }
                if (i == 2)
                {
                    EasyRightAnswer();
                    question1AAnswered = true;


                }
                if (i == 3)
                {
                    EasyWrongAnswer();
                }
            }

            if (slot1.text == secondQ)
            {
                if (i == 1)
                {
                    EasyWrongAnswer();
                }
                if (i == 2)
                {
                    EasyWrongAnswer();
                }
                if (i == 3)
                {
                    EasyRightAnswer();
                    question2AAnswered = true;
                }
            }

            if (slot1.text == thirdQ)
            {
                if (i == 1)
                {
                    EasyRightAnswer();
                    question3AAnswered = true;
                }
                if (i == 2)
                {
                    EasyWrongAnswer();
                }
                if (i == 3)
                {
                    EasyWrongAnswer();
                }
            }

            if (slot1.text == fourthQ)
            {
                if (i == 1)
                {
                    EasyRightAnswer();
                    question4AAnswered = true;
                }
                if (i == 2)
                {
                    EasyWrongAnswer();
                }
                if (i == 3)
                {
                    EasyWrongAnswer();
                }
            }

            if (slot1.text == fifthQ)
            {
                if (i == 1)
                {
                    EasyWrongAnswer();
                }
                if (i == 2)
                {
                    EasyWrongAnswer();
                }
                if (i == 3)
                {
                EasyRightAnswer();
                question5AAnswered = true;
                }
            }

            if (slot2.text == sixthQ)
            {
                if (j == 1)
                {
                    MediumRightAnswer();
                    question1BAnswered = true;
                }
                if (j == 2)
                {
                    MediumWrongAnswer();
                }
                if (j == 3)
                {
                    MediumWrongAnswer();
                }
            }

            if (slot2.text == seventhQ)
            {
                if (j == 1)
                {
                    MediumWrongAnswer();
                }
                if (j == 2)
                {
                    MediumRightAnswer();
                    question2BAnswered = true;
                }
                if (j == 3)
                {
                    MediumWrongAnswer();
                }
            }

            if (slot2.text == eightQ)
            {
                if (j == 1)
                {
                    MediumWrongAnswer();
                }
                if (j == 2)
                {
                    MediumWrongAnswer();
                }
                if (j == 3)
                {
                    MediumRightAnswer();
                    question3BAnswered = true;
                }
            }

            if (slot2.text == ninthQ)
            {
                if (j == 1)
                {
                    MediumRightAnswer();
                    question4BAnswered = true;
                }
                if (j == 2)
                {
                    MediumWrongAnswer();
                }
                if (j == 3)
                {
                    MediumWrongAnswer();
                }
            }

            if (slot2.text == tenthQ)
            {
                if (j == 1)
                {
                    MediumWrongAnswer();
                }
                if (j == 2)
                {
                    MediumRightAnswer();
                    question5BAnswered = true;
                }
                if (j == 3)
                {
                    MediumWrongAnswer();
                }
            }

            if(slot3.text == eleventhQ)
            {
                if(k == 1)
            {
                HardRightAnswer();
                question1CAnswered = true;
            }
                if(k==2)
            {
                HardWrongAnswer();
            }
                if(k==3)
            {
                HardWrongAnswer();
            }
            }

            if(slot3.text == twelthQ)
            {
                if(k==1)
            {
                HardWrongAnswer();
            }
                if(k==2)
            {
                HardRightAnswer();
                question2CAnswered = true;
            }
                if(k==3)
            {
                HardWrongAnswer();
            }
            }

            if(slot3.text == thirteenthQ)
            {
            if (k == 1)
            {
                HardWrongAnswer();
            }
            if(k==2)
            {
                HardWrongAnswer();
            }
            if(k==3)
            {
                HardRightAnswer();
                question3CAnswered = true;
            }
            }

            if(slot3.text == fourteenthQ)
            {
                if(k==1)
            {
                HardRightAnswer();
                question4CAnswered = true;
            }
                if(k==2)
            {
                HardWrongAnswer();
            }
                if(k==3)
            {
                HardWrongAnswer();
            }
            }

            if(slot3.text == fifteenthQ)
        {
            if(k==1)
            {
                HardWrongAnswer();
            }
            if(k==2)
            {
                HardWrongAnswer();
            }
            if(k==3)
            {
                HardRightAnswer();
                question5CAnswered = true;
            }
        }
        }

        public void EasyRightAnswer()
        {
            if (result1Wrong.activeSelf)
            {
                return;
            }
            if (result1Wrong.activeSelf == false)
            {
                PlayerStats.money += 100;
                question1.SetActive(false);
                result1Correct.SetActive(true);
            }
            i = 0;
        }

        public void MediumRightAnswer()
        {
            if (result2Wrong.activeSelf)
            {
                return;
            }
            if (result2Wrong.activeSelf == false)
            {
                PlayerStats.money += 200;
                question2.SetActive(false);
                result2Correct.SetActive(true);
            }
            j = 0;
        }

        public void HardRightAnswer()
        {
            if (result3Wrong.activeSelf)
            {
                return;
            }
            if (result3Wrong.activeSelf == false)
            {
                PlayerStats.money += 400;
                question3.SetActive(false);
                result3Correct.SetActive(true);
            }
            k = 0;
        }

        public void EasyWrongAnswer()
        {
            if (result1Correct.activeSelf)
            {
                return;
            }
            if (result1Correct.activeSelf == false)
            {
                question1.SetActive(false);
                result1Wrong.SetActive(true);
            }
            i = 0;
        }

        public void MediumWrongAnswer()
        {
            if (result2Correct.activeSelf)
            {
                return;
            }
            if (result2Correct.activeSelf == false)
            {
                question2.SetActive(false);
                result2Wrong.SetActive(true);
            }
            j = 0;
        }

        public void HardWrongAnswer()
        {
            if (result3Correct.activeSelf)
            {
                return;
            }
            if (result3Correct.activeSelf == false)
            {
                question3.SetActive(false);
                result3Wrong.SetActive(true);
            }
            k = 0;
        }

    public void LessThan20Questions()
    {
        if (question1AAnswered == false)
        {


            slot1.text = firstQ;
            slot1Answer1.text = answer1A;
            slot1Answer2.text = answer2A;
            slot1Answer3.text = answer3A;
        }
        if (question1AAnswered == true)
        {
            num += 20f;
        }
        if (question1AAnswered && question2AAnswered)
        {
            num += 40f;
        }
        if (question1AAnswered && question2AAnswered && question3AAnswered)
        {
            num += 60;
        }
        if (question1AAnswered && question2AAnswered && question3AAnswered && question4AAnswered)
        {
            num += 80;
        }

        if (question1BAnswered == false)
        {
            slot2.text = sixthQ;
            slot2Answer1.text = answer1F;
            slot2Answer2.text = answer2F;
            slot2Answer3.text = answer3F;
        }
        if (question1BAnswered)
        {
            num += 20f;
        }
        if (question2BAnswered && question1BAnswered)
        {
            num += 40f;
        }
        if (question1BAnswered && question2BAnswered && question3BAnswered)
        {
            num += 60f;
        }
        if (question1BAnswered && question2BAnswered && question3BAnswered && question4BAnswered)
        {
            num += 80f;
        }

        if (question1CAnswered == false)
        {
            slot3.text = eleventhQ;
            slot3Answer1.text = answer1K;
            slot3Answer2.text = answer2K;
            slot3Answer3.text = answer3K;
        }

        if (question1CAnswered)
        {
            num += 20f;
        }
        if (question1CAnswered && question2CAnswered)
        {
            num += 40f;
        }
        if (question1CAnswered && question2CAnswered && question3CAnswered)
        {
            num += 60f;
        }
        if (question4CAnswered && question3CAnswered && question2CAnswered && question1CAnswered)
        {
            num += 80f;
        }
    }

    public void Between20And40()
    {
        if (question2AAnswered == false)
        {

            slot1.text = secondQ;
            slot1Answer1.text = answer1B;
            slot1Answer2.text = answer2B;
            slot1Answer3.text = answer3B;
        }
        if (question2AAnswered == true)
        {
            num += 20f;
        }
        if (question2AAnswered && question3AAnswered)
        {
            num -= 20f;
        }
        if (question2AAnswered && question1AAnswered && question3AAnswered)
        {
            num += 40f;
        }
        if (question2AAnswered && question3AAnswered && question4AAnswered && question5AAnswered)
        {
            num -= 20f;
        }
        if (question1AAnswered && question2AAnswered && question3AAnswered && question4AAnswered)
        {
            num += 60f;
        }

        if (question2BAnswered == false)
        {
            slot2.text = seventhQ;
            slot2Answer1.text = answer1G;
            slot2Answer2.text = answer2G;
            slot2Answer3.text = answer3G;
        }
        if (question2BAnswered)
        {
            num -= 20f;
        }
        if (question2BAnswered && question1BAnswered)
        {
            num += 20f;
        }
        if (question2BAnswered && question1BAnswered && question3BAnswered)
        {
            num += 40f;
        }
        if (question2BAnswered && question1BAnswered && question3BAnswered && question4BAnswered)
        {
            num += 60f;
        }

        if(question2CAnswered == false)
        {
            slot3.text = twelthQ;
            slot3Answer1.text = answer1L;
            slot3Answer2.text = answer2L;
            slot3Answer3.text = answer3L;
        }
        if (question2CAnswered)
        {
            num -= 20f;
        }
        if (question2CAnswered && question1CAnswered)
        {
            num += 20f;
        }
        if (question2CAnswered && question1CAnswered && question3CAnswered)
        {
            num += 40f;
        }
        if (question2CAnswered && question1CAnswered && question3CAnswered && question4CAnswered)
        {
            num += 60f;
        }

    }

    public void Between40and60()
    {
        if (question3AAnswered == false)
        {
            slot1.text = thirdQ;
            slot1Answer1.text = answer1C;
            slot1Answer2.text = answer2C;
            slot1Answer3.text = answer3C;
        }
        if (question3AAnswered == true)
        {
            num -= 20f;
        }
        if (question3AAnswered && question2AAnswered)
        {
            num += 20f;
        }
        if (question3AAnswered && question4AAnswered)
        {
            num += 40f;
        }
        if (question3AAnswered && question2AAnswered && question4AAnswered)
        {
            num -= 40f;
        }
        if (question3AAnswered && question2AAnswered && question1AAnswered && question4AAnswered)
        {
            num += 40f;
        }
        if (question5AAnswered && question4AAnswered && question3AAnswered && question2AAnswered)
        {
            num -= 40f;
        }

        if (question3BAnswered == false)
        {
            slot2.text = eightQ;
            slot2Answer1.text = answer1H;
            slot2Answer2.text = answer2H;
            slot2Answer3.text = answer3H;
        }
        if (question3BAnswered)
        {
            num += 20f;
        }
        if (question3BAnswered && question4BAnswered)
        {
            num += 40f;
        }
        if (question4BAnswered && question3BAnswered && question5BAnswered)
        {
            num -= 20f;
        }
        if (question5BAnswered && question4BAnswered && question3BAnswered && question2BAnswered)
        {
            num -= 40f;
        }

        if(question3CAnswered == false)
        {
            slot3.text = thirteenthQ;
            slot3Answer1.text = answer1M;
            slot3Answer2.text = answer2M;
            slot3Answer3.text = answer3M;
        }
        if (question3CAnswered)
        {
            num += 20f;
        }
        if (question3CAnswered && question4CAnswered)
        {
            num += 40f;
        }
        if (question4CAnswered && question3CAnswered && question5CAnswered)
        {
            num -= 20f;
        }
        if (question5CAnswered && question4CAnswered && question3CAnswered && question2CAnswered)
        {
            num -= 40f;
        }

    }

    public void Between60And80()
    {
        if (question4AAnswered == false)
        {
            slot1.text = fourthQ;
            slot1Answer1.text = answer1D;
            slot1Answer2.text = answer2D;
            slot1Answer3.text = answer3D;
        }

        if (question4AAnswered)
        {
            num += 20f;
        }
        if (question4AAnswered && question5AAnswered)
        {
            num -= 20f;
        }
        if (question4AAnswered && question5AAnswered && question3AAnswered)
        {
            num -= 40f;
        }
        if (question4AAnswered && question5AAnswered && question3AAnswered && question2AAnswered)
        {
            num -= 60f;
        }

        if (question4BAnswered == false)
        {
            slot2.text = ninthQ;
            slot2Answer1.text = answer1I;
            slot2Answer2.text = answer2I;
            slot2Answer3.text = answer3I;
        }

        if (question4BAnswered)
        {
            num += 20f;
        }
        if (question4BAnswered && question5BAnswered)
        {
            num -= 20f;
        }
        if (question5BAnswered && question4BAnswered && question3BAnswered)
        {
            num -= 40f;
        }
        if (question3BAnswered && question2BAnswered && question4BAnswered && question5BAnswered)
        {
            num -= 60f;
        }

        if(question4CAnswered == false)
        {
            slot3.text = fourteenthQ;
            slot3Answer1.text = answer1N;
            slot3Answer2.text = answer2N;
            slot3Answer3.text = answer3N;
        }

        if (question4CAnswered)
        {
            num += 20f;
        }
        if (question4CAnswered && question5CAnswered)
        {
            num -= 20f;
        }
        if (question5CAnswered && question4CAnswered && question3CAnswered)
        {
            num -= 40f;
        }
        if (question3CAnswered && question2CAnswered && question4CAnswered && question5CAnswered)
        {
            num -= 60f;
        }
    }

    public void Over80()
    {
        if (question5AAnswered == false)
        {
            slot1.text = fifthQ;
            slot1Answer1.text = answer1E;
            slot1Answer2.text = answer2E;
            slot1Answer3.text = answer3E;
        }
        if (question5AAnswered)
        {
            num -= 20f;
        }
        if (question4AAnswered && question5AAnswered)
        {
            num -= 40f;
        }
        if (question5AAnswered && question4AAnswered && question3AAnswered)
        {
            num -= 60f;
        }
        if (question4AAnswered && question5AAnswered && question3AAnswered && question2AAnswered)
        {
            num -= 80f;
        }

        if (question5BAnswered == false)
        {
            slot2.text = tenthQ;
            slot2Answer1.text = answer1J;
            slot2Answer2.text = answer2J;
            slot2Answer3.text = answer3J;
        }
        if (question5BAnswered)
        {
            num -= 20f;
        }
        if (question4BAnswered && question5BAnswered)
        {
            num -= 40f;
        }
        if (question5BAnswered && question4BAnswered && question3BAnswered)
        {
            num -= 60f;
        }
        if (question2BAnswered && question3BAnswered && question4BAnswered && question5BAnswered)
        {
            num -= 80f;
        }

        if(question5CAnswered == false)
        {
            slot3.text = fifteenthQ;
            slot3Answer1.text = answer1O;
            slot3Answer2.text = answer2O;
            slot3Answer3.text = answer3O;
        }

        if (question5CAnswered)
        {
            num -= 20f;
        }
        if (question4CAnswered && question5CAnswered)
        {
            num -= 40f;
        }
        if (question5CAnswered && question4CAnswered && question3CAnswered)
        {
            num -= 60f;
        }
        if (question2CAnswered && question3CAnswered && question4CAnswered && question5CAnswered)
        {
            num -= 80f;
        }

    }
    
}
