﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStats : MonoBehaviour
{
    public static int money;
    public int startMoney = 400;
    public int startLives;
    public static int Lives;

    public static int rounds;
    public void Start()
    {
        money = startMoney;
        Lives = startLives;

        rounds = 0;
    }

   
}
