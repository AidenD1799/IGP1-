﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Enemy : MonoBehaviour
{
    public float startSpeed = 10f;
    [HideInInspector]
    public float speed;

    public Image healthBar;

    

    public float startHealth = 100f;
    public float health;

    public int worth = 50;

    void Start()
    {
        speed = startSpeed;
        health = startHealth;
    }
    
    public void TakeDamage(float amount)
    {
        health -= amount;

        healthBar.fillAmount = health / startHealth;

        if (health <= 0)
        {
            Die();
        }
    }

    public void Slow(float pct)
    {
        speed = startSpeed * (1f - pct);
    }

    public void Die()
    {
        PlayerStats.money += worth;
        Destroy(gameObject);
        WaveSpawner.enemiesAlive--;

    }

    
   
}
