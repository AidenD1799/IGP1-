﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WaveSpawner : MonoBehaviour
{
    public static int enemiesAlive = 0;

    public Wave[] waves;

    //Used to assign an enemy object to the spawner
    public Transform enemyPrefab;

    //Used to assign a place for the enemies to spawn
    public Transform spawnPoint;

    //Used to determine the time period between enemy spawns
    public float timeBetweenWaves = 5f;
    private float countdown = 2f;

    //Used to display a timer which indicates the time between waves
    public Text waveCountdownText;

    private int waveIndex = 1;

    Enemy enemy;

    //Used to continually spawn enemies
    void Update()
    {
        if (enemiesAlive > 0)
        {
            return;
        }
        //When the countdown reaches zero seconds a wave of enemies will spawn
        if (countdown <= 0f)
        {
            StartCoroutine(SpawnWave());
            countdown = timeBetweenWaves;
            return;
        }

        //Counts down from 5
        countdown -= Time.deltaTime;

        countdown = Mathf.Clamp(countdown, 0f, Mathf.Infinity);

        //Displays the current countdown in the UI
        waveCountdownText.text = string.Format("{0:00.00}", countdown);
    }

    //Coroutine used to spawn a wave of enemies
    IEnumerator SpawnWave()
    {
      
        PlayerStats.rounds++;

        Wave wave = waves[waveIndex];

        for (int i = 0; i < wave.count; i++)
        {
            SpawnEnemy(wave.enemy);
            yield return new WaitForSeconds(1f/wave.rate);
        }
        waveIndex++;
       
        
    }

    //Method used to create enemy objects
    void SpawnEnemy(GameObject enemy)
    {
        Instantiate(enemy, spawnPoint.position, spawnPoint.rotation);
        enemiesAlive++;
    }

     
}
